import React from "react";
import '../assets/css/footer.css';
import img1 from '../assets/images/facebook.png'
import img2 from '../assets/images/twitter.png'
import img3 from '../assets/images/instagram.png'

export default function Footer() {
  return 

  <div id="footer">
			<div class="footer-section">
				<div class="section-content about">
					<h2>About Us</h2>
					<p>Springfield Pet Rescue is dedicated to rescuing and rehoming pets in the Western Province of Sri Lanka. Our mission is to provide a safe and loving environment for all animals in our care.</p>
				</div>
			</div>
			<div class="footer-section">
				<div class="section-content contact">
					<h2>Contact Us</h2>
					<ul>
						<li><a href="mailto:info@springfieldpetrescue.com">info@springfieldpetrescue.com</a></li>
						<li>011 22 88770</li>
						<li>No.12, Dickmens Rd, Springfield, Western Province, Sri Lanka</li>
					</ul>
				</div>
			</div>
			<div class="footer-section">
				<div class="section-content social">
					<h2>Follow Us</h2>
					<div class="social-icons">
            <img src={img1} alt="facebook" />
            <img src={img2} alt="twitter" />
            <img src={img3} alt="instagram" />
					</div>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; 2024 Springfield Pet Rescue. All Rights Reserved.
			</div>
		</div>
}