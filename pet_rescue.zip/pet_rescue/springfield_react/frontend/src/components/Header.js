import React from 'react'
import img1 from '../assets/images/logo.jpg'
import '../assets/css/header.css'


export default function Header() {
  return (
    <header>
        
       <div class="logo">
            <a href="index.php">
              <img src={img1} alt="logo" />
            </a>
            <span class="title">Springfield Pet Rescue</span>

        </div>
    </header>
  )
}