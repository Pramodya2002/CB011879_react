import React from 'react'
import '../assets/css/menu.css'

export default function Menu() {
  return (
    <ul>
      <li><a href="/">Home</a>  </li>
      <li className="dropdown"><a href="/users" className="dropbtn">Users</a>
        <div className="dropdown-content">
          <a href="/users">User Management</a>
          <a href="/see-all-cities">See All</a>
        </div>
      </li>

      {/* drop menu for News */}
      <li className="dropdown"> <a href="javascript:void(0)" classNameName="dropbtn">Pets</a>
        <div className="dropdown-content">
          <a href="/pets">Pet Management</a>
       
        </div>
      </li>
      <li><a href="/volunteers">Volunteers</a>  </li>
      
      <li><a target='blank' href="http://localhost/PAWS/index.php">Springfield Pet Rescue</a>  </li>
    </ul>
  )
}