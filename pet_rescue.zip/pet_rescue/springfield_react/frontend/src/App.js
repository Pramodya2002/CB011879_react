import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./pages/homePage";
import Layout from "./components/Layout";
import Users from "./pages/users";
import Cities from "./pages/cities";
import Pets from "./pages/pets";
import Volunteer from "./pages/volunteer";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route key={"Layout"} path="/" element={<Layout />}>
          <Route key={"homePage"} path="/" element={<Home />} />
          <Route key={"users"} path="/users" element={<Users />} />
          <Route key={"cities"} path="/see-all-cities" element={<Cities />} />
          <Route key={"pets"} path="/pets" element={<Pets />} />
          <Route key={"volunteers"} path="/volunteers" element={<Volunteer />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
