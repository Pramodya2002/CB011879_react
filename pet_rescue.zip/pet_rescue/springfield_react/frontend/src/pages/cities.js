import React, { useState, useEffect } from "react";
import apiClient from "./../service/axiosService";
import { apis } from "../Apis/apis";
import { Col, Row, Card } from "antd";

const Cities = () => {
  const [citiesList, setCitiesList] = useState([]);

  useEffect(() => {
    getCities();
  }, []);

  const getCities = async () => {
    const response = await apiClient.get(apis.getCities);
    if (response.status == 200) {
      setCitiesList(response.data);
    }
  };
  return (
    <Row>
      {citiesList.map((city, index) => (
        <Col sm={6} md={4} lg={3} key={index}>
          <Card
            style={{
              margin: "10px",
              textAlign: "center",
              backgroundColor: "#e6f7ff", // Light blue background
              border: "1px solid #91caff", // Blue border
              borderRadius: "8px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
              transition: "transform 0.2s",
              padding: "8px", // Reduced padding for smaller size
              height: "100px", // Fixed height for consistent card size
            }}

            hoverable // Makes card hoverable
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "scale(1.05)"; // Scale on hover
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "scale(1)"; // Reset scale
            }}
          >
            {city.names[0]?.name}
            </Card>
        </Col>
      ))}
        
    </Row>
  );
};
export default Cities;
