import React from "react";
import '../assets/css/hero.css'
const Home =()=>{
    return (
        <main>
            <section class="hero">
                <div class="hero-text">
                    <h1>Welcome to Springfield Pet Rescue</h1>
                    <p>Finding loving homes for stray and abandoned pets in the Western Province of Sri Lanka.</p>
                </div>
            </section>

            <section className="about-us">
                <h2>About Us</h2>
                <p>At Springfield Pet Rescue, we believe every pet deserves a loving home. Our mission is to rescue, rehabilitate, and rehome stray and abandoned animals. Join us in making a difference!</p>
            </section>

            <section className="adoption-process">
                <h2>Adoption Process</h2>
                <ol>
                    <li>Browse our available pets.</li>
                    <li>Fill out an adoption application.</li>
                    <li>Meet your potential new furry friend!</li>
                    <li>Complete the adoption paperwork.</li>
                    <li>Welcome your new pet home!</li>
                </ol>
            </section>

            <section className="volunteer-opportunities">
                <h2>Volunteer Opportunities</h2>
                <p>We are always looking for passionate volunteers to help us in our mission. Whether you can walk dogs, foster pets, or help with events, there is a place for you!</p>
            </section>

            <section className="donations">
                <h2>Support Us</h2>
                <p>Your donations make a big difference! Consider making a monetary donation or donating supplies such as food, blankets, and toys.</p>
            </section>

            <section className="upcoming-events">
                <h2>Upcoming Events</h2>
                <p>Join us for our next adoption event or fundraiser! Stay tuned for more details.</p>
            </section>
        
        </main>
        
       
      

    )
}
export default Home;