import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../assets/css/volunteers.css'; 

const Volunteers = () => {
  const [volunteers, setVolunteers] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [status, setStatus] = useState('');
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchVolunteers();
  }, []);

  // Fetch all volunteers from the backend
  const fetchVolunteers = async () => {
    try {
      const response = await axios.get('http://localhost:3001/volunteers');
      setVolunteers(response.data);
    } catch (error) {
      console.error('Error fetching volunteers', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const volunteerData = { name, email, role, status };

    if (editId === null) {
      // Add new volunteer
      try {
        await axios.post('http://localhost:3001/volunteers', volunteerData);
        fetchVolunteers(); // Refresh volunteer list
      } catch (error) {
        console.error('Error adding volunteer', error);
      }
    } else {
      // Update existing volunteer
      try {
        await axios.put(`http://localhost:3001/volunteers/${editId}`, volunteerData);
        fetchVolunteers(); // Refresh volunteer list
        setEditId(null); // Reset edit mode
      } catch (error) {
        console.error('Error updating volunteer', error);
      }
    }

    setName('');
    setEmail('');
    setRole('');
    setStatus('');
  };

  // Handle delete volunteer
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/volunteers/${id}`);
      fetchVolunteers(); // Refresh volunteer list
    } catch (error) {
      console.error('Error deleting volunteer', error);
    }
  };

  // Handle edit volunteer
  const handleEdit = (volunteer) => {
    setName(volunteer.name);
    setEmail(volunteer.email);
    setRole(volunteer.role);
    setStatus(volunteer.status);
    setEditId(volunteer.id); // Set edit mode
  };

  return (
    <div className="container">
      <h2>Volunteer Management</h2>
      <form className="form" onSubmit={handleSubmit}>
        <input
          className="input-field"
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          required
        />
        <select
          className="input-field"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          required
        >
          <option value="">Status</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
        <button className="submit-btn" type="submit">
          {editId !== null ? 'Update Volunteer' : 'Add Volunteer'}
        </button>
      </form>

      <h3>Volunteer List</h3>
      {volunteers.length === 0 ? (
        <p>No volunteers available</p>
      ) : (
        <table className="user-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {volunteers.map((volunteer) => (
              <tr key={volunteer.id}>
                <td>{volunteer.name}</td>
                <td>{volunteer.email}</td>
                <td>{volunteer.role}</td>
                <td>{volunteer.status}</td>
                <td>
                  <button onClick={() => handleEdit(volunteer)}>Edit</button>
                  <button onClick={() => handleDelete(volunteer.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Volunteers;
