import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../assets/css/pets.css';

const Pets = () => {
  const [pets, setPets] = useState([]);
  const [pet_name, setPetName] = useState('');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const [adoption_status, setAdoptionStatus] = useState('');
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchPets();
  }, []);

  // Fetch all pets from the backend
  const fetchPets = async () => {
    try {
      const response = await axios.get('http://localhost:3001/pets');
      setPets(response.data);
    } catch (error) {
      console.error('Error fetching pets', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const petData = { pet_name, breed, age, adoption_status };

    if (editId === null) {
      // Add new pet
      try {
        await axios.post('http://localhost:3001/pets', petData);
        fetchPets(); // Refresh pet list
      } catch (error) {
        console.error('Error adding pet', error);
      }
    } else {
      // Update existing pet
      try {
        await axios.put(`http://localhost:3001/pets/${editId}`, petData);
        fetchPets(); // Refresh pet list
        setEditId(null); // Reset edit mode
      } catch (error) {
        console.error('Error updating pet', error);
      }
    }

    setPetName('');
    setBreed('');
    setAge('');
    setAdoptionStatus('');
  };

  // Handle delete pet
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/pets/${id}`);
      fetchPets(); // Refresh pet list
    } catch (error) {
      console.error('Error deleting pet', error);
    }
  };

  // Handle edit pet
  const handleEdit = (pet) => {
    setPetName(pet.pet_name);
    setBreed(pet.breed);
    setAge(pet.age);
    setAdoptionStatus(pet.adoption_status);
    setEditId(pet.id); // Set edit mode
  };

  return (
    <div className="container">
      <h2>Pet Adoption Management</h2>
      <form className="form" onSubmit={handleSubmit}>
        <input
          className="input-field"
          type="text"
          placeholder="Pet Name"
          value={pet_name}
          onChange={(e) => setPetName(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Breed"
          value={breed}
          onChange={(e) => setBreed(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="number"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          required
        />
        <select
          className="input-field"
          value={adoption_status}
          onChange={(e) => setAdoptionStatus(e.target.value)}
          required
        >
          <option value="">Adoption Status</option>
          <option value="Available">Available</option>
          <option value="Adopted">Adopted</option>
        </select>
        <button className="submit-btn" type="submit">
          {editId !== null ? 'Update Pet' : 'Add Pet'}
        </button>
      </form>

      <h3>Pet List</h3>
      {pets.length === 0 ? (
        <p>No pets available</p>
      ) : (
        <table className="user-table">
          <thead>
            <tr>
              <th>Pet Name</th>
              <th>Breed</th>
              <th>Age</th>
              <th>Adoption Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {pets.map((pet) => (
              <tr key={pet.id}>
                <td>{pet.pet_name}</td>
                <td>{pet.breed}</td>
                <td>{pet.age}</td>
                <td>{pet.adoption_status}</td>
                <td>
                  <button onClick={() => handleEdit(pet)}>Edit</button>
                  <button onClick={() => handleDelete(pet.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Pets;
