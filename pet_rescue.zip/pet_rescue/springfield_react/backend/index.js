const express = require('express');
const bodyParser = require('body-parser');
const dbConfig = require('./config.js');
const mysql = require('mysql');
const cors = require('cors'); // Import the CORS middleware
const nodemailer = require('nodemailer');

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors()); // Enable CORS for all routes

// Middleware
app.use(bodyParser.json());

// MySQL connection
const connection = mysql.createConnection(dbConfig);

connection.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// email service begin 
const transporter = nodemailer.createTransport({
  port: 465,               // true for 465, false for other ports
  host: "smtp.gmail.com",
  auth: {
    user: 'myemailm207@gmail.com',
    pass: 'qekn fdbt gbbs utwv',
  },
  secure: true,
  });
  // qekn fdbt gbbs utwv

// API endpoint to send email
app.post('/send-email', (req, res) => {
  const { to, subject, text } = req.body;

  const mailOptions = {
    from: 'myemailm207@gmail.com',
    to,
    subject,
    text,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      res.status(500).send('Error sending email');
    } else {
      console.log('Email sent: ' + info.response);
      res.status(200).send('Email sent');
    }
  });
});

// CRUD Operations

// Create a new user
app.post('/users', (req, res) => {
  const { name, email } = req.body;
  const sql = 'INSERT INTO users (name, email) VALUES (?, ?)';
  connection.query(sql, [name, email], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(201).send('User added with ID: ${result.insertId}');
});
});

// Read all users
app.get('/users', (req, res) => {
  const sql = 'SELECT * FROM users';
  connection.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(200).json(results);
});
});


// Update a user by ID
app.put('/users/:id', (req, res) => {
  const { id } = req.params;
  const { name, email } = req.body;
  const sql = 'UPDATE users SET name = ?, email = ? WHERE id = ?';
  connection.query(sql, [name, email, id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('User not found');
    }
    res.status(200).send('User updated successfully');
});
});

// Delete a user by ID
app.delete('/users/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM users WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('User not found');
    }
    res.status(200).send('User deleted successfully');
});
});

// Create a new pet
app.post('/pets', (req, res) => {
  const { pet_name, breed, age, adoption_status } = req.body;
  const sql = 'INSERT INTO pets (pet_name, breed, age, adoption_status) VALUES (?, ?, ?, ?)';
  connection.query(sql, [pet_name, breed, age, adoption_status], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(201).send(`Pet added with ID: ${result.insertId}`);
  });
});

// Get all pets
app.get('/pets', (req, res) => {
  const sql = 'SELECT * FROM pets';
  connection.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(200).json(results);
  });
});

// Get a single pet by ID
app.get('/pets/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM pets WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.length === 0) {
      return res.status(404).send('Pet not found');
    }
    res.status(200).json(result[0]);
  });
});

// Update a pet by ID
app.put('/pets/:id', (req, res) => {
  const { id } = req.params;
  const { pet_name, breed, age, adoption_status } = req.body;
  const sql = 'UPDATE pets SET pet_name = ?, breed = ?, age = ?, adoption_status = ? WHERE id = ?';
  connection.query(sql, [pet_name, breed, age, adoption_status, id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Pet not found');
    }
    res.status(200).send('Pet updated successfully');
  });
});

// Delete a pet by ID
app.delete('/pets/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM pets WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Pet not found');
    }
    res.status(200).send('Pet deleted successfully');
  });
});

// Create a new volunteer
app.post('/volunteers', (req, res) => {
  const { name, email, phone, role, status } = req.body;
  const sql = 'INSERT INTO volunteers (name, email, phone, role, status) VALUES (?, ?, ?, ?, ?)';
  connection.query(sql, [name, email, phone, role, status], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(201).send(`Volunteer added with ID: ${result.insertId}`);
  });
});

// Read all volunteers
app.get('/volunteers', (req, res) => {
  const sql = 'SELECT * FROM volunteers';
  connection.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(200).json(results);
  });
});

// Get a single volunteer by ID
app.get('/volunteers/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM volunteers WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.length === 0) {
      return res.status(404).send('Volunteer not found');
    }
    res.status(200).json(result[0]);
  });
});

// Update a volunteer by ID
app.put('/volunteers/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, phone, role, status } = req.body;
  const sql = 'UPDATE volunteers SET name = ?, email = ?, phone = ?, role = ?, status = ? WHERE id = ?';
  connection.query(sql, [name, email, phone, role, status, id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Volunteer not found');
    }
    res.status(200).send('Volunteer updated successfully');
  });
});

// Delete a volunteer by ID
app.delete('/volunteers/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM volunteers WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Volunteer not found');
    }
    res.status(200).send('Volunteer deleted successfully');
  });
});



// Start the server
app.listen(port, () => {
  console.log('Server running at http://localhost:${port}/');
});